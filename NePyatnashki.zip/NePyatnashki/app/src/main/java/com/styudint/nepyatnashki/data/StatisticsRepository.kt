package com.styudint.nepyatnashki.data

import android.arch.lifecycle.LiveData

interface StatisticsRepository {
    fun statistics(): LiveData<List<GameInfo>>
    fun saveGame()
}